
## Obiettivo

Sostituire completamente il database Lovable Cloud con il Google Sheet indicato come unica fonte dati per l'inventario dell'armadietto.

Foglio: `10-otF3oL9tOu_E0uxREuS1gTisrUtJFRHVKTzJyJMEo`

## Passi

### 1. Collegare Google Sheets
Linko il connettore Google Sheets al progetto. Si aprirà un popup per autorizzare l'account Google che possiede (o ha accesso in scrittura a) il foglio.

### 2. Preparare il foglio
Sul foglio (Sheet1, riga 1) servono le intestazioni:

```
id | nome | quantita | formato | scadenza | posizione | created_at | updated_at
```

Posso scriverle io al primo avvio se sono assenti.

### 3. Server functions di lettura/scrittura
Creo `src/lib/armadietto.functions.ts` con quattro `createServerFn` che chiamano il gateway Google Sheets:

- `listFarmaci()` → `GET .../values/Sheet1!A2:H` 
- `addFarmaco(data)` → `POST .../values/Sheet1!A:H:append?valueInputOption=USER_ENTERED`
- `updateFarmaco(id, data)` → trova la riga per id, poi `PUT .../values/Sheet1!A{row}:H{row}`
- `deleteFarmaco(id)` → `POST .../values:batchUpdate` con `deleteDimension` per la riga

Gli `id` restano UUID generati lato server (compatibili con la UI attuale).

### 4. Aggiornare i componenti
Sostituire in `src/routes/inventario.tsx` e `src/routes/aggiungi.tsx` le chiamate a `supabase.from('armadietto')` con `useServerFn(...)` + TanStack Query. Il pattern dati e l'UI non cambiano.

### 5. Pulizia
- Rimuovo la tabella `public.armadietto` con una migration (dopo che il flusso Sheets funziona).
- Mantengo Lovable Cloud attivo (serve come runtime server, non viene rimosso).

## Tradeoff confermati
- Scritture ~1-2s (chiamata HTTP a Google).
- Niente realtime/live update fra utenti diversi.
- Limite ~60 richieste/minuto per utente Google (più che sufficiente per uso personale).
- Il foglio deve restare accessibile all'account collegato.

## Dettagli tecnici
- Auth: connettore Google Sheets (OAuth dell'account che colleghi), gateway `https://connector-gateway.lovable.dev/google_sheets/v4`.
- Range A1: `Sheet1!A:H` (no encoding del `:`).
- `valueInputOption=USER_ENTERED` per parsing date corretto.
- Tipi: `quantita` come number, `scadenza` come `YYYY-MM-DD` testo.
