
CREATE TABLE public.armadietto (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  nome TEXT NOT NULL,
  quantita INTEGER NOT NULL DEFAULT 1,
  formato TEXT,
  scadenza DATE,
  posizione TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.armadietto TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.armadietto TO authenticated;
GRANT ALL ON public.armadietto TO service_role;

ALTER TABLE public.armadietto ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public read armadietto" ON public.armadietto FOR SELECT USING (true);
CREATE POLICY "Public insert armadietto" ON public.armadietto FOR INSERT WITH CHECK (true);
CREATE POLICY "Public update armadietto" ON public.armadietto FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "Public delete armadietto" ON public.armadietto FOR DELETE USING (true);

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_armadietto_updated_at
BEFORE UPDATE ON public.armadietto
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
