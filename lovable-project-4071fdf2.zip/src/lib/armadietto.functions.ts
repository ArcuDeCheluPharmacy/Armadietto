import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const SPREADSHEET_ID = "10-otF3oL9tOu_E0uxREuS1gTisrUtJFRHVKTzJyJMEo";
const GATEWAY = "https://connector-gateway.lovable.dev/google_sheets/v4";
const HEADER_ROW = ["id", "nome", "quantita", "formato", "scadenza", "posizione", "created_at", "updated_at"];

let cachedSheet: { title: string; sheetId: number } | null = null;

function authHeaders() {
  const lovable = process.env.LOVABLE_API_KEY;
  const conn = process.env.GOOGLE_SHEETS_API_KEY;
  if (!lovable) throw new Error("LOVABLE_API_KEY missing");
  if (!conn) throw new Error("GOOGLE_SHEETS_API_KEY missing (collega Google Sheets)");
  return {
    Authorization: `Bearer ${lovable}`,
    "X-Connection-Api-Key": conn,
  };
}

async function gw(path: string, init: RequestInit = {}) {
  const res = await fetch(`${GATEWAY}${path}`, {
    ...init,
    headers: {
      ...authHeaders(),
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Google Sheets ${res.status}: ${body}`);
  }
  return res.json();
}

async function getSheet() {
  if (cachedSheet) return cachedSheet;
  const meta = await gw(`/spreadsheets/${SPREADSHEET_ID}?fields=sheets.properties`);
  const first = meta.sheets?.[0]?.properties;
  if (!first) throw new Error("Nessun foglio trovato nello spreadsheet");
  cachedSheet = { title: first.title, sheetId: first.sheetId };
  return cachedSheet;
}

async function ensureHeader() {
  const sheet = await getSheet();
  const range = `${sheet.title}!A1:H1`;
  const data = await gw(`/spreadsheets/${SPREADSHEET_ID}/values/${range}`);
  const current = (data.values?.[0] ?? []) as string[];
  if (HEADER_ROW.every((h, i) => current[i] === h)) return sheet;
  await gw(
    `/spreadsheets/${SPREADSHEET_ID}/values/${range}?valueInputOption=RAW`,
    { method: "PUT", body: JSON.stringify({ values: [HEADER_ROW] }) },
  );
  return sheet;
}

export type Farmaco = {
  id: string;
  nome: string;
  quantita: number;
  formato: string | null;
  scadenza: string | null;
  posizione: string | null;
  created_at: string;
  updated_at: string;
};

function rowToFarmaco(row: string[]): Farmaco | null {
  if (!row?.[0]) return null;
  return {
    id: row[0],
    nome: row[1] ?? "",
    quantita: Number(row[2] ?? 0) || 0,
    formato: row[3] ? String(row[3]) : null,
    scadenza: row[4] ? String(row[4]) : null,
    posizione: row[5] ? String(row[5]) : null,
    created_at: row[6] ?? "",
    updated_at: row[7] ?? "",
  };
}

async function readAll(): Promise<{ rows: Farmaco[]; sheetTitle: string; sheetId: number; rawRows: string[][] }> {
  const sheet = await ensureHeader();
  const data = await gw(`/spreadsheets/${SPREADSHEET_ID}/values/${sheet.title}!A2:H`);
  const values: string[][] = data.values ?? [];
  const rows = values.map(rowToFarmaco).filter((r): r is Farmaco => r !== null);
  return { rows, sheetTitle: sheet.title, sheetId: sheet.sheetId, rawRows: values };
}

const farmacoInputSchema = z.object({
  nome: z.string().min(1).max(200),
  quantita: z.number().int().min(0).max(99999),
  formato: z.string().max(200).nullable().optional(),
  scadenza: z.string().max(20).nullable().optional(),
  posizione: z.string().max(200).nullable().optional(),
});

export const listFarmaciFn = createServerFn({ method: "GET" }).handler(async () => {
  const { rows } = await readAll();
  return rows;
});

export const getFarmacoFn = createServerFn({ method: "GET" })
  .inputValidator((d: { id: string }) => z.object({ id: z.string().min(1) }).parse(d))
  .handler(async ({ data }) => {
    const { rows } = await readAll();
    return rows.find((r) => r.id === data.id) ?? null;
  });

export const createFarmacoFn = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => farmacoInputSchema.parse(d))
  .handler(async ({ data }) => {
    const sheet = await ensureHeader();
    const now = new Date().toISOString();
    const id = crypto.randomUUID();
    const row = [
      id,
      data.nome,
      data.quantita,
      data.formato ?? "",
      data.scadenza ?? "",
      data.posizione ?? "",
      now,
      now,
    ];
    await gw(
      `/spreadsheets/${SPREADSHEET_ID}/values/${sheet.title}!A:H:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,
      { method: "POST", body: JSON.stringify({ values: [row] }) },
    );
    return { id };
  });

export const updateFarmacoFn = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z.object({ id: z.string().min(1), input: farmacoInputSchema }).parse(d),
  )
  .handler(async ({ data }) => {
    const { rawRows, sheetTitle } = await readAll();
    const idx = rawRows.findIndex((r) => r[0] === data.id);
    if (idx === -1) throw new Error("Farmaco non trovato");
    const sheetRow = idx + 2; // header is row 1
    const existing = rawRows[idx];
    const updated = [
      data.id,
      data.input.nome,
      data.input.quantita,
      data.input.formato ?? "",
      data.input.scadenza ?? "",
      data.input.posizione ?? "",
      existing[6] ?? new Date().toISOString(),
      new Date().toISOString(),
    ];
    await gw(
      `/spreadsheets/${SPREADSHEET_ID}/values/${sheetTitle}!A${sheetRow}:H${sheetRow}?valueInputOption=USER_ENTERED`,
      { method: "PUT", body: JSON.stringify({ values: [updated] }) },
    );
    return { ok: true };
  });

export const deleteFarmacoFn = createServerFn({ method: "POST" })
  .inputValidator((d: { id: string }) => z.object({ id: z.string().min(1) }).parse(d))
  .handler(async ({ data }) => {
    const { rawRows, sheetId } = await readAll();
    const idx = rawRows.findIndex((r) => r[0] === data.id);
    if (idx === -1) throw new Error("Farmaco non trovato");
    const sheetRow = idx + 1; // 0-indexed; header at index 0, data at index 1+
    await gw(`/spreadsheets/${SPREADSHEET_ID}:batchUpdate`, {
      method: "POST",
      body: JSON.stringify({
        requests: [
          {
            deleteDimension: {
              range: {
                sheetId,
                dimension: "ROWS",
                startIndex: sheetRow,
                endIndex: sheetRow + 1,
              },
            },
          },
        ],
      }),
    });
    return { ok: true };
  });
