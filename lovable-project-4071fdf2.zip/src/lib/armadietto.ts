import {
  listFarmaciFn,
  getFarmacoFn,
  createFarmacoFn,
  updateFarmacoFn,
  deleteFarmacoFn,
  type Farmaco,
} from "./armadietto.functions";

export type { Farmaco };

export type FarmacoInput = {
  nome: string;
  quantita: number;
  formato?: string | null;
  scadenza?: string | null;
  posizione?: string | null;
};

function normalize(input: FarmacoInput) {
  return {
    nome: input.nome.trim(),
    quantita: Number(input.quantita) || 0,
    formato: input.formato?.toString().trim() || null,
    scadenza: input.scadenza?.toString().trim() || null,
    posizione: input.posizione?.toString().trim() || null,
  };
}

export async function fetchFarmaci(): Promise<Farmaco[]> {
  const rows = await listFarmaciFn();
  return [...rows].sort((a, b) => a.nome.localeCompare(b.nome, "it"));
}

export async function fetchFarmaco(id: string): Promise<Farmaco | null> {
  return await getFarmacoFn({ data: { id } });
}

export async function createFarmaco(input: FarmacoInput) {
  await createFarmacoFn({ data: normalize(input) });
}

export async function updateFarmaco(id: string, input: FarmacoInput) {
  await updateFarmacoFn({ data: { id, input: normalize(input) } });
}

export async function deleteFarmaco(id: string) {
  await deleteFarmacoFn({ data: { id } });
}

/** Days until expiry. Negative = expired. Null if no date. */
export function daysUntil(date: string | null): number | null {
  if (!date) return null;
  const d = new Date(date + "T00:00:00");
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return Math.floor((d.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
}

export function expiryStatus(date: string | null): "expired" | "soon" | "ok" | "none" {
  const d = daysUntil(date);
  if (d === null) return "none";
  if (d < 0) return "expired";
  if (d <= 30) return "soon";
  return "ok";
}
