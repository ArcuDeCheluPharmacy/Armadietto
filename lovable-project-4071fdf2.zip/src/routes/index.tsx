import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Search, Package, AlertTriangle, CalendarClock, Plus } from "lucide-react";

import { fetchFarmaci, expiryStatus, daysUntil } from "@/lib/armadietto";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Armadietto — Home" },
      { name: "description", content: "Dashboard del tuo armadietto dei farmaci con ricerca rapida." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const { data: farmaci = [], isLoading } = useQuery({
    queryKey: ["farmaci"],
    queryFn: fetchFarmaci,
  });

  const stats = useMemo(() => {
    const totale = farmaci.reduce((acc, f) => acc + f.quantita, 0);
    const scaduti = farmaci.filter((f) => expiryStatus(f.scadenza) === "expired").length;
    const inScadenza = farmaci.filter((f) => expiryStatus(f.scadenza) === "soon").length;
    return { totale, scaduti, inScadenza, voci: farmaci.length };
  }, [farmaci]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return farmaci
      .filter(
        (f) =>
          f.nome.toLowerCase().includes(q) ||
          (f.posizione ?? "").toLowerCase().includes(q) ||
          (f.formato ?? "").toLowerCase().includes(q),
      )
      .slice(0, 6);
  }, [farmaci, query]);

  return (
    <div className="space-y-10">
      {/* Hero search */}
      <section className="relative overflow-hidden rounded-3xl border border-border bg-card p-8 shadow-[var(--shadow-card)] sm:p-12">
        <div className="absolute inset-0 -z-10 opacity-[0.07]" style={{ background: "var(--gradient-hero)" }} />
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-medium uppercase tracking-widest text-primary">Il tuo armadietto</p>
          <h1 className="mt-2 text-4xl font-semibold sm:text-5xl">Cosa stai cercando?</h1>
          <p className="mt-3 text-muted-foreground">Cerca un farmaco per nome, posizione o formato.</p>

          <div className="relative mx-auto mt-8 max-w-xl">
            <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="...."
              className="h-14 rounded-2xl border-border bg-background pl-12 pr-4 text-base shadow-[var(--shadow-soft)] focus-visible:ring-2"
            />
          </div>

          {query && (
            <div className="mx-auto mt-4 max-w-xl rounded-2xl border border-border bg-background text-left shadow-[var(--shadow-card)]">
              {results.length === 0 ? (
                <div className="p-6 text-center text-sm text-muted-foreground">
                  Nessun farmaco trovato.{" "}
                  <Link to="/aggiungi" className="font-medium text-primary hover:underline">
                    Aggiungilo ora
                  </Link>
                </div>
              ) : (
                <ul className="divide-y divide-border">
                  {results.map((f) => {
                    const d = daysUntil(f.scadenza);
                    const status = expiryStatus(f.scadenza);
                    return (
                      <li key={f.id}>
                        <button
                          onClick={() => navigate({ to: "/aggiungi", search: { id: f.id } })}
                          className="flex w-full items-center justify-between gap-3 p-4 text-left hover:bg-muted/60"
                        >
                          <div className="min-w-0">
                            <div className="truncate font-medium">{f.nome}</div>
                            <div className="truncate text-xs text-muted-foreground">
                              {[f.formato, f.posizione].filter(Boolean).join(" · ") || "—"}
                            </div>
                          </div>
                          <div className="flex shrink-0 items-center gap-2">
                            <Badge variant="secondary">×{f.quantita}</Badge>
                            {status === "expired" && <Badge className="bg-destructive text-destructive-foreground">Scaduto</Badge>}
                            {status === "soon" && d !== null && <Badge className="bg-warning text-warning-foreground">{d}g</Badge>}
                          </div>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Stats + Actions */}
      <section className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <Link to="/inventario" className="group">
          <Card className="flex h-full flex-col justify-between p-5 transition-shadow hover:shadow-[var(--shadow-soft)]">
            <div className="mb-3 inline-flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Package className="h-4 w-4" />
            </div>
            <div>
              <div className="text-lg font-semibold">Inventario completo</div>
              <div className="text-xs text-muted-foreground">Esplora tutti i farmaci</div>
            </div>
          </Card>
        </Link>
        <Link to="/aggiungi" className="group">
          <Card className="flex h-full flex-col justify-between p-5 transition-shadow hover:shadow-[var(--shadow-soft)]">
            <div className="mb-3 inline-flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Plus className="h-4 w-4" />
            </div>
            <div>
              <div className="text-lg font-semibold">Aggiungi farmaco</div>
              <div className="text-xs text-muted-foreground">Inserisci una nuova scatola</div>
            </div>
          </Card>
        </Link>
        <StatCard icon={CalendarClock} label="In scadenza ≤30g" value={isLoading ? "…" : String(stats.inScadenza)} tone="warning" />
        <StatCard icon={AlertTriangle} label="Scaduti" value={isLoading ? "…" : String(stats.scaduti)} tone="destructive" />
      </section>

    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  tone,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  tone: "primary" | "muted" | "warning" | "destructive";
}) {
  const toneClass = {
    primary: "bg-primary/10 text-primary",
    muted: "bg-muted text-muted-foreground",
    warning: "bg-warning/15 text-warning-foreground",
    destructive: "bg-destructive/10 text-destructive",
  }[tone];
  return (
    <Card className="p-5">
      <div className={`mb-3 inline-flex h-9 w-9 items-center justify-center rounded-lg ${toneClass}`}>
        <Icon className="h-4 w-4" />
      </div>
      <div className="text-2xl font-semibold">{value}</div>
      <div className="text-xs text-muted-foreground">{label}</div>
    </Card>
  );
}
