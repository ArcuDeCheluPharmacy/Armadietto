import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { z } from "zod";
import { zodValidator, fallback } from "@tanstack/zod-adapter";
import { ArrowLeft, Home, Save } from "lucide-react";
import { toast } from "sonner";

import {
  createFarmaco,
  fetchFarmaco,
  updateFarmaco,
  type FarmacoInput,
} from "@/lib/armadietto";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

const searchSchema = z.object({
  id: fallback(z.string().optional(), undefined),
});

export const Route = createFileRoute("/aggiungi")({
  validateSearch: zodValidator(searchSchema),
  head: () => ({
    meta: [
      { title: "Aggiungi farmaco — Armadietto" },
      { name: "description", content: "Inserisci o modifica un farmaco nell'armadietto." },
    ],
  }),
  component: AggiungiPage,
});

function AggiungiPage() {
  const { id } = Route.useSearch();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const isEdit = !!id;

  const { data: existing, isLoading } = useQuery({
    queryKey: ["farmaco", id],
    queryFn: () => fetchFarmaco(id!),
    enabled: isEdit,
  });

  const [form, setForm] = useState<FarmacoInput>({
    nome: "",
    quantita: 1,
    formato: "",
    scadenza: "",
    posizione: "",
  });
  const [errors, setErrors] = useState<Partial<Record<keyof FarmacoInput, string>>>({});

  useEffect(() => {
    if (existing) {
      setForm({
        nome: existing.nome,
        quantita: existing.quantita,
        formato: existing.formato ?? "",
        scadenza: existing.scadenza ?? "",
        posizione: existing.posizione ?? "",
      });
    }
  }, [existing]);

  const mutation = useMutation({
    mutationFn: async (input: FarmacoInput) => {
      if (isEdit) await updateFarmaco(id!, input);
      else await createFarmaco(input);
    },
    onSuccess: () => {
      toast.success(isEdit ? "Farmaco aggiornato" : "Farmaco aggiunto");
      qc.invalidateQueries({ queryKey: ["farmaci"] });
      qc.invalidateQueries({ queryKey: ["farmaco", id] });
      navigate({ to: "/inventario" });
    },
    onError: () => toast.error("Errore durante il salvataggio"),
  });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const schema = z.object({
      nome: z.string().trim().min(1, "Il nome è obbligatorio").max(120),
      quantita: z.number().int().min(0, "Almeno 0").max(9999),
      formato: z.string().trim().max(80).optional().or(z.literal("")),
      scadenza: z.string().optional().or(z.literal("")),
      posizione: z.string().trim().max(80).optional().or(z.literal("")),
    });
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      const errs: Partial<Record<keyof FarmacoInput, string>> = {};
      parsed.error.issues.forEach((i) => {
        errs[i.path[0] as keyof FarmacoInput] = i.message;
      });
      setErrors(errs);
      return;
    }
    setErrors({});
    mutation.mutate({
      nome: parsed.data.nome,
      quantita: parsed.data.quantita,
      formato: parsed.data.formato || null,
      scadenza: parsed.data.scadenza || null,
      posizione: parsed.data.posizione || null,
    });
  }

  if (isEdit && isLoading) {
    return <Card className="p-10 text-center text-muted-foreground">Caricamento...</Card>;
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div className="flex items-center gap-4">
        <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
          <Home className="h-4 w-4" /> Torna alla home
        </Link>
        <Link to="/inventario" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Torna all'inventario
        </Link>
      </div>

      <header>
        <h1 className="text-3xl font-semibold sm:text-4xl">{isEdit ? "Modifica farmaco" : "Aggiungi farmaco"}</h1>
        <p className="mt-1 text-muted-foreground">
          {isEdit ? "Aggiorna le informazioni della scatola." : "Inserisci una nuova scatola nell'armadietto."}
        </p>
      </header>

      <Card className="p-6 sm:p-8">
        <form onSubmit={handleSubmit} className="space-y-5">
          <Field label="Nome farmaco" error={errors.nome} required>
            <Input
              autoFocus
              value={form.nome}
              onChange={(e) => setForm({ ...form, nome: e.target.value })}
              placeholder="...."
              maxLength={120}
            />
          </Field>

          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Quantità (scatole)" error={errors.quantita} required>
              <Input
                type="number"
                min={0}
                max={9999}
                value={form.quantita}
                onChange={(e) => setForm({ ...form, quantita: Number(e.target.value) || 0 })}
              />
            </Field>
            <Field label="Formato" error={errors.formato as string | undefined}>
              <Input
                value={form.formato ?? ""}
                onChange={(e) => setForm({ ...form, formato: e.target.value })}
                placeholder="...."
                maxLength={80}
              />
            </Field>
          </div>

          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Scadenza" error={errors.scadenza as string | undefined}>
              <Input
                type="date"
                value={form.scadenza ?? ""}
                onChange={(e) => setForm({ ...form, scadenza: e.target.value })}
              />
            </Field>
            <Field label="Posizione cassetto" error={errors.posizione as string | undefined}>
              <Input
                value={form.posizione ?? ""}
                onChange={(e) => setForm({ ...form, posizione: e.target.value })}
                placeholder="...."
                maxLength={80}
              />
            </Field>
          </div>

          <div className="flex flex-wrap justify-end gap-3 pt-2">
            <Button type="button" variant="ghost" asChild>
              <Link to="/inventario">Annulla</Link>
            </Button>
            <Button type="submit" disabled={mutation.isPending}>
              <Save className="mr-1.5 h-4 w-4" />
              {mutation.isPending ? "Salvataggio..." : isEdit ? "Salva modifiche" : "Aggiungi al cassetto"}
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}

function Field({
  label,
  error,
  required,
  children,
}: {
  label: string;
  error?: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-sm font-medium">
        {label}
        {required && <span className="text-destructive"> *</span>}
      </Label>
      {children}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}
