import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { ArrowUpDown, Pencil, Trash2, Plus, Search, Package, Home } from "lucide-react";
import { toast } from "sonner";

import { deleteFarmaco, expiryStatus, fetchFarmaci, daysUntil, type Farmaco } from "@/lib/armadietto";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

type SortKey = "nome" | "scadenza" | "quantita" | "posizione";
type SortDir = "asc" | "desc";

export const Route = createFileRoute("/inventario")({
  head: () => ({
    meta: [
      { title: "Inventario — Armadietto" },
      { name: "description", content: "Elenco ordinabile di tutti i farmaci dell'armadietto domestico." },
    ],
  }),
  component: Inventario,
});

function Inventario() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("nome");
  const [sortDir, setSortDir] = useState<SortDir>("asc");

  const { data: farmaci = [], isLoading } = useQuery({
    queryKey: ["farmaci"],
    queryFn: fetchFarmaci,
  });

  const del = useMutation({
    mutationFn: deleteFarmaco,
    onSuccess: () => {
      toast.success("Farmaco eliminato");
      qc.invalidateQueries({ queryKey: ["farmaci"] });
    },
    onError: () => toast.error("Errore durante l'eliminazione"),
  });

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    const filtered = q
      ? farmaci.filter(
          (f) =>
            f.nome.toLowerCase().includes(q) ||
            (f.posizione ?? "").toLowerCase().includes(q) ||
            (f.formato ?? "").toLowerCase().includes(q),
        )
      : farmaci;
    const sorted = [...filtered].sort((a, b) => {
      const dir = sortDir === "asc" ? 1 : -1;
      const av = a[sortKey];
      const bv = b[sortKey];
      if (av === null || av === undefined) return 1;
      if (bv === null || bv === undefined) return -1;
      if (typeof av === "number" && typeof bv === "number") return (av - bv) * dir;
      return String(av).localeCompare(String(bv), "it") * dir;
    });
    return sorted;
  }, [farmaci, search, sortKey, sortDir]);

  function toggleSort(k: SortKey) {
    if (sortKey === k) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(k);
      setSortDir("asc");
    }
  }

  return (
    <div className="space-y-6">
      <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <Home className="h-4 w-4" /> Torna alla home
      </Link>
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold sm:text-4xl">Inventario</h1>
          <p className="mt-1 text-muted-foreground">
            {farmaci.length} {farmaci.length === 1 ? "voce" : "voci"} nell'armadietto
          </p>
        </div>
        <Button asChild>
          <Link to="/aggiungi">
            <Plus className="mr-1.5 h-4 w-4" /> Aggiungi
          </Link>
        </Button>
      </header>

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filtra per nome, posizione, formato..."
            className="pl-9"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <SortPill active={sortKey === "nome"} dir={sortDir} onClick={() => toggleSort("nome")}>Nome</SortPill>
          <SortPill active={sortKey === "scadenza"} dir={sortDir} onClick={() => toggleSort("scadenza")}>Scadenza</SortPill>
          <SortPill active={sortKey === "quantita"} dir={sortDir} onClick={() => toggleSort("quantita")}>Quantità</SortPill>
          <SortPill active={sortKey === "posizione"} dir={sortDir} onClick={() => toggleSort("posizione")}>Posizione</SortPill>
        </div>
      </div>

      {isLoading ? (
        <Card className="p-10 text-center text-muted-foreground">Caricamento...</Card>
      ) : rows.length === 0 ? (
        <Card className="flex flex-col items-center gap-3 p-12 text-center">
          <Package className="h-10 w-10 text-muted-foreground" />
          <p className="text-muted-foreground">
            {farmaci.length === 0 ? "L'armadietto è ancora vuoto." : "Nessun farmaco corrisponde alla ricerca."}
          </p>
          {farmaci.length === 0 && (
            <Button asChild className="mt-2">
              <Link to="/aggiungi">Aggiungi il primo farmaco</Link>
            </Button>
          )}
        </Card>
      ) : (
        <Card className="overflow-hidden p-0">
          <div className="hidden grid-cols-[2fr_1fr_1fr_1.2fr_1fr_auto] gap-4 border-b border-border bg-muted/50 px-5 py-3 text-xs font-medium uppercase tracking-wider text-muted-foreground md:grid">
            <button onClick={() => toggleSort("nome")} className="flex items-center gap-1 text-left hover:text-foreground">Nome <ArrowUpDown className="h-3 w-3" /></button>
            <button onClick={() => toggleSort("quantita")} className="flex items-center gap-1 text-left hover:text-foreground">Q.tà <ArrowUpDown className="h-3 w-3" /></button>
            <span>Formato</span>
            <button onClick={() => toggleSort("scadenza")} className="flex items-center gap-1 text-left hover:text-foreground">Scadenza <ArrowUpDown className="h-3 w-3" /></button>
            <button onClick={() => toggleSort("posizione")} className="flex items-center gap-1 text-left hover:text-foreground">Posizione <ArrowUpDown className="h-3 w-3" /></button>
            <span className="text-right">Azioni</span>
          </div>
          <ul className="divide-y divide-border">
            {rows.map((f) => (
              <Row key={f.id} f={f} onEdit={() => navigate({ to: "/aggiungi", search: { id: f.id } })} onDelete={() => del.mutate(f.id)} />
            ))}
          </ul>
        </Card>
      )}
    </div>
  );
}

function SortPill({
  active,
  dir,
  onClick,
  children,
}: {
  active: boolean;
  dir: SortDir;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-1 rounded-full border px-3 py-1.5 text-xs font-medium transition ${
        active
          ? "border-primary bg-primary text-primary-foreground"
          : "border-border bg-card text-muted-foreground hover:text-foreground"
      }`}
    >
      {children}
      {active && <span className="ml-0.5">{dir === "asc" ? "↑" : "↓"}</span>}
    </button>
  );
}

function Row({ f, onEdit, onDelete }: { f: Farmaco; onEdit: () => void; onDelete: () => void }) {
  const status = expiryStatus(f.scadenza);
  const d = daysUntil(f.scadenza);
  const scadenzaLabel = f.scadenza
    ? new Date(f.scadenza + "T00:00:00").toLocaleDateString("it-IT", { day: "2-digit", month: "short", year: "numeric" })
    : "—";

  return (
    <li className="grid grid-cols-2 gap-x-4 gap-y-1 px-5 py-4 md:grid-cols-[2fr_1fr_1fr_1.2fr_1fr_auto] md:items-center md:gap-4">
      <div className="col-span-2 md:col-span-1">
        <div className="font-medium">{f.nome}</div>
        <div className="text-xs text-muted-foreground md:hidden">{f.formato || "—"}</div>
      </div>
      <div className="text-sm">
        <span className="md:hidden text-muted-foreground">Q.tà: </span>×{f.quantita}
      </div>
      <div className="hidden text-sm text-muted-foreground md:block">{f.formato || "—"}</div>
      <div className="text-sm">
        <div className="flex items-center gap-2">
          <span>{scadenzaLabel}</span>
          {status === "expired" && <Badge className="bg-destructive text-destructive-foreground">Scaduto</Badge>}
          {status === "soon" && d !== null && <Badge className="bg-warning text-warning-foreground">{d}g</Badge>}
        </div>
      </div>
      <div className="text-sm text-muted-foreground">{f.posizione || "—"}</div>
      <div className="col-span-2 flex justify-end gap-1 md:col-span-1">
        <Button variant="ghost" size="icon" onClick={onEdit} aria-label="Modifica">
          <Pencil className="h-4 w-4" />
        </Button>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="ghost" size="icon" aria-label="Elimina" className="text-destructive hover:text-destructive">
              <Trash2 className="h-4 w-4" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Eliminare "{f.nome}"?</AlertDialogTitle>
              <AlertDialogDescription>L'azione non può essere annullata.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Annulla</AlertDialogCancel>
              <AlertDialogAction onClick={onDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                Elimina
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </li>
  );
}
